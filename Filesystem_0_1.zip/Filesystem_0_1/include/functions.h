#pragma once
#include <iostream>
void Log(const char* text)
{
  std::cout << text << std::endl;
}
