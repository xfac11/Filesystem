#include "shell.h"
#include "fs.h"
#include "disk.h"

int main()
{
  Shell shell;
  shell.run();
  return 0;
}
